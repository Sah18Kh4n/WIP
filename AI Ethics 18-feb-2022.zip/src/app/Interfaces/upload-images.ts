export interface UploadImages {
          id:number,
          description:string,
          path:string
}
