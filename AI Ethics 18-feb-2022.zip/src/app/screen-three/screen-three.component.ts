import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-screen-three',
  templateUrl: './screen-three.component.html',
  styleUrls: ['./screen-three.component.scss']
})
export class ScreenThreeComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
