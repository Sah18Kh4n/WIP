import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-screen-two',
  templateUrl: './screen-two.component.html',
  styleUrls: ['./screen-two.component.scss']
})
export class ScreenTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
