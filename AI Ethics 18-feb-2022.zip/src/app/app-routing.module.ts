import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CatalogDashboardComponent } from './catalog-dashboard/catalog-dashboard.component';
import { ScreenThreeComponent } from './screen-three/screen-three.component';
import { ScreenTwoComponent } from './screen-two/screen-two.component';
import { Screen1NavComponent } from './screen1-nav/screen1-nav.component';

const routes: Routes = [
  {
    path: '',
    component: Screen1NavComponent,
  },
  {
    path: 'screen2',
    component: ScreenTwoComponent,
  },
  {
    path: 'screen3',
    component: ScreenThreeComponent,
  },
  {
    path: 'screen4',
    component: CatalogDashboardComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
